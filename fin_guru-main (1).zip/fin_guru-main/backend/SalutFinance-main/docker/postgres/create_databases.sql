CREATE DATABASE finances_db;

GRANT ALL PRIVILEGES ON DATABASE finances_db to "postgres";