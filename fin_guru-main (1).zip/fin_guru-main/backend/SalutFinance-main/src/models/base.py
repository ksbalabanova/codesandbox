from sqlalchemy.orm import DeclarativeBase


class BaseModel(DeclarativeBase):
    pass
